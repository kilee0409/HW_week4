import './assets/scss/all.scss';

console.log("Hello world!");